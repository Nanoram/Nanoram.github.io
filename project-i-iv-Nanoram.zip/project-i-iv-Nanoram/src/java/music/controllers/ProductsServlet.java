/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music.controllers;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import music.data.ProductIO;
import music.business.Product;

/**
 *
 * @author Caleb Allen Servlet that handles all the actions sent from the jsp
 * pages
 */
@WebServlet(name = "ProductsServlet", urlPatterns = {"/ProductsServlet"})
public class ProductsServlet extends HttpServlet {

    /**
     * Function that gets the file path from for the text file, then sends that
     * file path to the productIO so the products list can be created
     *
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        String filePath = this.getServletContext().getRealPath("/WEB-INF/products.txt");
        ProductIO.init(filePath);
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String url = "/index.jsp";
        Product product = new Product();
        List<Product> products;
        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "join";  // default action
        }
        switch (action) {
            case "update":
                url = "/products.jsp";
                String oldProductCode = request.getParameter("oldProductCode");
                String newCode = request.getParameter("codeNumber");
                String description = request.getParameter("description");
                String price = request.getParameter("price");
                String message = validateValues(newCode, description, price);
                if (!isDouble(price)) {
                    message += " Entered Incorrect Value.";
                    price = "0.00";
                }   
                if (!message.isEmpty()) {
                    if (price.startsWith("$")) {
                        url = "/editProduct.jsp";
                        product.setCode(newCode);
                        product.setDescription(description);
                        product.setPrice(Double.parseDouble(price.substring(1)));
                        request.setAttribute("product", product);
                        request.setAttribute("message", message);
                    } else {
                        url = "/editProduct.jsp";
                        product.setCode(newCode);
                        product.setDescription(description);
                        product.setPrice(Double.parseDouble(price));
                        request.setAttribute("product", product);
                        request.setAttribute("message", message);
                    }
                } else {
                    if (price.startsWith("$")) {
                        products = updateProducts(oldProductCode, newCode, description, Double.parseDouble(price.substring(1)));
                        ProductIO.saveProducts(products);
                        request.setAttribute("products", products);
                    } else {
                        products = updateProducts(oldProductCode, newCode, description, Double.parseDouble(price));
                        ProductIO.saveProducts(products);
                        request.setAttribute("products", products);
                    }
                }

                break;
            case "delete":
                url = "/products.jsp";
                String code = request.getParameter("productCode");
                product = ProductIO.selectProduct(code);
                ProductIO.deleteProduct(product);
                products = ProductIO.selectProducts();
                ProductIO.saveProducts(products);
                request.setAttribute("products", products);
                break;
        }

        // perform action and set URL to appropriate page
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = "/index.jsp";
        Product product;
        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "join";  // default action
        }
        switch (action) {
            case "edit":
                url = "/editProduct.jsp";
                String code = request.getParameter("productCode");
                product = ProductIO.selectProduct(code);
                request.setAttribute("product", product);
                break;
            case "productList":
                url = "/products.jsp";
                List<Product> products = ProductIO.selectProducts();
                request.setAttribute("products", products);
                break;
            case "delete":
                url = "/DeletePage.jsp";
                code = request.getParameter("productCode");
                product = ProductIO.selectProduct(code);
                request.setAttribute("product", product);
                break;
        }
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    /**
     * Function used to edit/add a product. When adding a product the object
     * returns a null value so I create a new product and insert it into the
     * list. When editing a product I wanted the old product to be deleted and a
     * new one created, otherwise it would make another product entirely.
     *
     * @param oldProductCode parameter to get the edited products original
     * product code
     * @param newCode parameter for possible new code entered by user
     * @param description parameter for possible new description
     * @param price parameter for possible new price
     * @return updated product list
     */
    public List updateProducts(String oldProductCode, String newCode, String description, double price) {
        Product product;
        product = ProductIO.selectProduct(oldProductCode);
        if (product == null) {
            product = new Product();
            product.setCode(newCode);
            product.setDescription(description);
            product.setPrice(price);
            ProductIO.insertProduct(product);
            return ProductIO.selectProducts();
        } else {
            ProductIO.deleteProduct(product);
            product.setCode(newCode);
            product.setDescription(description);
            product.setPrice(price);
            ProductIO.insertProduct(product);
            return ProductIO.selectProducts();
        }
    }

    public String validateValues(String newCode, String description, String price) {
        String message = "";
        if (newCode == null || description == null || price == null
                || newCode.isEmpty() || description.isEmpty() || price.isEmpty()) {
            message += "Please fill out all text boxes.";
        }
        return message;
    }

    public boolean isDouble(String price) {
        try {
            if (price.startsWith("$")) {
                if (Double.parseDouble(price.substring(1)) < 0) {
                    return false;
                } else {
                    Double.parseDouble(price.substring(1));
                    return true;
                }
            } else {
                if (Double.parseDouble(price) < 0) {
                    return false;
                } else {
                    Double.parseDouble(price);
                    return true;
                }
            }

        } catch (NumberFormatException e) {
            return false;
        }
    }
}
