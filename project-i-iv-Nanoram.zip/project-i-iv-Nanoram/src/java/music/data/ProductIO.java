package music.data;

import java.io.*;
import java.util.*;

import music.business.*;

/**
 * ProductIO class Provides methods for reading and writing products to a text
 * file.
 *
 * @author yourNameGoesHere
 */
public class ProductIO {

    private static List<Product> products = null;
    private static String filePath = null;

    /**
     * This function is called once from controller based on servlet context to
     * initialize the filePath instance variable.
     *
     * @param filePath
     */
    public static void init(String filePath) {
        ProductIO.filePath = filePath;
    }

    /**
     * This method reads the products file to build a list of Product objects.
     *
     * @return a list of Product objects
     */
    public static List<Product> selectProducts() {
        products = new ArrayList<>();
        File file = new File(filePath);
        try (BufferedReader in = new BufferedReader(
                new FileReader(file))) {
            String line;
            while ((line = in.readLine()) != null) {
                String[] productInfo = line.split("\\|");
                if (productInfo.length >= 3) {
                    Product product = new Product();
                    product.setCode(productInfo[0]);
                    product.setDescription(productInfo[1]);
                    product.setPrice(Double.parseDouble(productInfo[2]));

                    products.add(product);
                }
            }
        } catch (IOException e) {
            System.out.println(e);
            return null;
        }
        return products;
    }

    /**
     * Gets a specific product from the list of product objects. This method
     * first updates the products list before searching for a product in the
     * list.
     *
     * @param productCode the string value specifying the product code
     * @return the Product object if the product code is found; otherwise null
     */
    public static Product selectProduct(String productCode) {
        if (productCode != null) {
            products = selectProducts();
            for (Product product : products) {
                if (productCode.equalsIgnoreCase(product.getCode())) {
                    return product;
                }
            }
        }
        return null;
    }

    /**
     * Checks if a specific product exists within the list of product objects.
     *
     * @param productCode the string value specifying the product code
     * @return true if exists; otherwise false
     */
    public static boolean exists(String productCode) {
        return selectProduct(productCode) != null;
    }

    /**
     * Saves the products in the list to the products text file.
     *
     * @param products the list of Product objects to be saved
     */
    public static void saveProducts(List<Product> products) {
        try {
            File file = new File(filePath);
            try (PrintWriter out = new PrintWriter(
                    new FileWriter(file))) {
                StringBuilder productInfo = new StringBuilder();
                for (Product product : products) {
                    productInfo.append(product.getCode())
                            .append("|")
                            .append(product.getDescription())
                            .append("|")
                            .append(product.getPrice())
                            .append("\n");
                }
                out.println(productInfo.toString());
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /**
     * Adds a Product object to the products list and then saves. This method
     * first updates the products list before adding the product to the list.
     * Once added, the list is saved to the products file.
     *
     * @param product the Product to be added to the list
     */
    public static void insertProduct(Product product) {
        products = selectProducts();
        products.add(product);
        saveProducts(products);
    }

    /**
     * Updates a Product object in the products list and then saves. This method
     * first updates the products list before updating a product in the list.
     * Once update, the list is saved to the products file.
     *
     * @param product the Product to be updated in the list
     */
    public static void updateProduct(Product product) {
        if (product.getCode() != null) {
            products = selectProducts();
            for (Product productToUpdate : products) {
                if (productToUpdate.getCode().equalsIgnoreCase(product.getCode())) {
                    products.set(products.indexOf(productToUpdate), product);
                    break;
                }
            }
            saveProducts(products);
        }
    }

    /**
     * Deletes a Product object in the products list and then saves. This method
     * first updates the products list before deleting a product in the list.
     * Once deleted, the list is saved to the products file.
     *
     * @param product the Product to be deleted from the list
     */
    public static void deleteProduct(Product product) {
        if (product != null) {
            products = selectProducts();
            for (Product productToDelete : products) {
                if (productToDelete.getCode().equalsIgnoreCase(product.getCode())) {
                    products.remove(productToDelete);
                    break;
                }
            }
            saveProducts(products);
        }
    }
}