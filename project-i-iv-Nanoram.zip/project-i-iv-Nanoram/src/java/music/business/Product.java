package music.business;

import java.text.NumberFormat;
import java.io.Serializable;

/**
 * Product class
 * Provides the means for creating Product business objects as JavaBeans
 * 
 * @author yourNameGoesHere
 */
public class Product implements Serializable {

    private String code;
    private String description;
    private double price;
    

    

    /**
     * Default zero parameter constructor which initializes the instance variables
     */
    public Product() {
        this.code = "";
        this.description = "";
        this.price = 0;
    }

    /**
     * Sets the code for the product.
     * 
     * @param code the product code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the code for the product.
     * 
     * @return the value of code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the description for the product.
     * 
     * @param description the product description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the description for the product.
     * 
     * @return the value of description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Gets the artist name from the product description.
     * 
     * @return the artist name
     */
    public String getArtistName() {
        String artistName
                = description.substring(0, description.indexOf(" - "));
        return artistName;
    }

    /**
     * Gets the album name from the product description.
     * 
     * @return the album name
     */
    public String getAlbumName() {
        String albumName
                = description.substring(description.indexOf(" - ") + 3);
        return albumName;
    }

    /**
     * Sets the price for the product.
     * 
     * @param price the product price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Gets the price for the product.
     * 
     * @return the product price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Gets the product price in a number format.
     * 
     * @return the formatted produce price
     */
    public String getPriceNumberFormat() {
        NumberFormat number = NumberFormat.getNumberInstance();
        number.setMinimumFractionDigits(2);
        if (price == 0) {
            return "";
        } else {
            return number.format(price);
        }
    }
    
    /**
     * Gets the product price in a currency format.
     * 
     * @return the formatted product price
     */
    public String getPriceCurrencyFormat() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(price);
    }

    /**
     * Gets the image URL using the product code.
     * 
     * @return the image URL
     */
    public String getImageURL() {
        String imageURL = "/musicStore/images/" + code + "_cover.jpg";
        return imageURL;
    }

    /**
     * Get the product type.
     * 
     * @return the product type.
     */
    public String getProductType() {
        return "Audio CD";
    }
}